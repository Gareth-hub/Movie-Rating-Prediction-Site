<?php

$apikey = "970978636001c77562e47fa0d71bf7ea";

$sitename = "Lime movies";
$tagline = "Jack Flahive lime";
$email = "flahive.jack123@gmail.com";
$url = "http://jackflahive.net";

$imgurl_1 = "http://image.tmdb.org/t/p/w500";
$imgurl_2 = "http://image.tmdb.org/t/p/w300";

?>
